import express from 'express';
import Joi from './../middlewares/joi';
import * as schemas from './../schemas/user';
// import { tokenAuth, basicAuth } from './../middlewares/auth';

import Controller from './../controllers/configuration';

const configurationRoutes = () => {
  const router = express.Router();

  router.get(
    '/',
    // tokenAuth,
    // scopes('user:create'),
    // CheckUserTypesSchema,
    async (req, res) => {
      try {
        const user = await Controller.getConfig(req);
        res.status(200).send(user);
      } catch (e) {
        res.status(e.code || 400).send(e);
      }
    }
  );

  return router;
};

export default configurationRoutes;
