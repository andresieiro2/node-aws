import 'babel-polyfill';

import app from './app';

import serverless from 'serverless-http';

module.exports.run = serverless(app);
