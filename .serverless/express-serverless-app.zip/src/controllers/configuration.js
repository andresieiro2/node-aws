import * as Configuration from './../models/configuration';

const configurationController = {
  getConfig: async (req, res) => await Configuration.getConfig(req),
};

export default configurationController;
