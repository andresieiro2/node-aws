import config from 'config';
import { callService } from './../utils/fetch';

export const getConfig = async req => {
  try {
    const config = await callService(
      `${config.get(
        'API_GOREAD'
      )}/configuration//?app_id=goread&os_version=ios&device_type=ipad&revision=`
    );

    return config;
  } catch (e) {
    console.log(e);

    return e;
  }
};
